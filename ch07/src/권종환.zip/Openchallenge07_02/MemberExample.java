package Openchallenge07_02;

public class MemberExample {
	public static void main(String[] args) {
		Member member = new Member("1234", 100000, "홍길동", "010-1234-5678", "대전시 서구 월평동");

		member.show();
	}
}
