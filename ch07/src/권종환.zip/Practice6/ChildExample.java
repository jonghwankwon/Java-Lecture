package Practice6;

public class ChildExample {
	public static void main(String[] args) {
		Child chid = new Child();
	}
}
/*
출력 결과
Parent(String nation) call
Parent() call
Child(String name) call
Child() call

*/